// simple.fs
//
// copy primary color

void main(void)
{
    // Copy the primary color
    gl_FragColor = gl_Color;
}
