//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GLView.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GLVIEW_DIALOG               102
#define IDR_MAINFRAME                   128
#define IDB_OPENGL                      130
#define IDB_BM_NOGL                     131
#define IDB_BITMAP1                     132
#define IDB_BITMAP2                     133
#define IDB_BITMAP3                     134
#define IDB_BITMAP4                     135
#define IDB_BITMAP5                     136
#define IDB_BITMAP6                     137
#define IDD_GLVIEW_PFORMAT              138
#define IDC_LIST                        205
#define IDC_VENDOR                      206
#define IDC_RENDERER                    207
#define IDC_VERSION                     208
#define IDC_GLUVERSION                  209
#define IDC_TEST_FRAME                  1001
#define IDC_LST_EXT                     1002
#define IDC_LST_EXT2                    1003
#define IDC_BUTTON1                     1004
#define IDC_ED_SIZE                     1005
#define IDC_BUTTON2                     1005
#define IDC_CH_DOUBLEBUFFER             1006
#define IDC_ED_VERSION                  1007
#define IDC_ED_FLAGS                    1008
#define IDC_ED_PIXELTYPE                1021
#define IDC_ED_COLORBITS                1022
#define IDC_ED_REDBITS                  1023
#define IDC_ED_REDSHIFT                 1024
#define IDC_ED_GREENBITS                1025
#define IDC_ED_GREENSHIFT               1026
#define IDC_ED_ALPHABITS                1027
#define IDC_ED_ALPHASHIFT               1028
#define IDC_ED_BLUEBITS                 1031
#define IDC_ED_BLUESHIFT                1032
#define IDC_ED_RESERVED                 1033
#define IDC_ED_ACCUMBITS                1034
#define IDC_ED_ACCUMREDBITS             1035
#define IDC_ED_ACCUMGREENBITS           1036
#define IDC_ED_ACCUMBLUEBITS            1037
#define IDC_ED_ACCUMALPHABITS           1038
#define IDC_ED_AUXBUFFERS               1039
#define IDC_ED_LAYERTYPE                1040
#define IDC_ED_DEPTHBITS                1041
#define IDC_ED_STENCILBITS              1042
#define IDC_ED_VISIBLEMASK              1043
#define IDC_ED_DAMAGEMASK               1044
#define IDC_ED_LAYERMASK                1045
#define IDC_CH_STEREO                   1046
#define IDC_CH_DRAW_TO_WINDOW           1047
#define IDC_CH_DRAW_TO_BITMAP           1048
#define IDC_CH_SUPPORT_GDI              1049
#define IDC_CH_SUPPORT_OPENGL           1050
#define IDC_CH_GENERIC_FORMAT           1051
#define IDC_CH_NEED_PALETTE             1052
#define IDC_CH_NEED_SYSTEM_PALETTE      1053
#define IDC_CH_SWAP_EXCHANGE            1054
#define IDC_CH_SWAP_COPY                1055
#define IDC_CH_SWAP_LAYER_BUFFERS       1056
#define IDC_CH_GENERIC_ACCELERATED      1057
#define IDC_CH_SUPPORT_DIRECTDRAW       1058
#define IDC_ED_PIXELTYPETEXT            1063
#define IDC_ED_RESERVEDTEXT             1064
#define IDC_CH_INVALID_BITS             1065
#define IDC_ED_FORMAT                   1067

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
