//
//  AppDelegate.h
//  GLES-Learning
//
//  Created by charles on 2018/4/18.
//  Copyright © 2018年 charles. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

