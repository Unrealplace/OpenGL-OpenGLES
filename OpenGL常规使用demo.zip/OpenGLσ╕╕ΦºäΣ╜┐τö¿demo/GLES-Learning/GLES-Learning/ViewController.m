//
//  ViewController.m
//  GLES-Learning
//
//  Created by charles on 2018/4/18.
//  Copyright © 2018年 charles. All rights reserved.
//

#import "ViewController.h"
#import <GLKit/GLKit.h>

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
#ifndef __APPLE__
    EEE eee;
//    EAGLContext
//    GLKView
    
#endif
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
