//
//  PieChart.hpp
//  ComputerGraphics
//
//  Created by charles on 2018/4/24.
//  Copyright © 2018年 charles. All rights reserved.
//

#ifndef PieChart_hpp
#define PieChart_hpp

#include <stdio.h>

#include <GLUT/glut.h>

void pieChartInit();
void pieChart();
void displayFuncPieChart(void);
void winReshapeFuncPieChart(GLint newWidth, GLint newHeight);

#endif /* PieChart_hpp */
