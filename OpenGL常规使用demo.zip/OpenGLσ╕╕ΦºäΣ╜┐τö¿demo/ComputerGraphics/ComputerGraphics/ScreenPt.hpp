//
//  ScreenPt.hpp
//  ComputerGraphics
//
//  Created by charles on 2018/4/22.
//  Copyright © 2018年 charles. All rights reserved.
//

#ifndef ScreenPt_hpp
#define ScreenPt_hpp

#include <stdio.h>

void initScreenPt(void);
void regHexagon(void);
void winReshapeFun2(int newWidth, int newHeight);

#endif /* ScreenPt_hpp */
