//
//  GLUT.h
//  GLUT
//
//  Created by charles on 2018/4/10.
//

#import <Cocoa/Cocoa.h>

//! Project version number for GLUT.
FOUNDATION_EXPORT double GLUTVersionNumber;

//! Project version string for GLUT.
FOUNDATION_EXPORT const unsigned char GLUTVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GLUT/PublicHeader.h>


